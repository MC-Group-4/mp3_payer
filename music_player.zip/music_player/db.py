import sqlite3
from sqlite3 import Error


def create_connection():

    connection = sqlite3.connect(music.db)
    return connection
