import youtube_dl
import os



url = input('enter a url: ')

options = {
'format': 'bestaudio/best',
'outtmpl': 'music/%(title)s.%(ext)s',
'postprocessors': [{
    'key': 'FFmpegExtractAudio',
    'preferredcodec': 'mp3',
    'preferredquality': '192',
}],
'postprocessor_args': [
    '-ar', '16000'
],
'prefer_ffmpeg': True,
'keepvideo': False
}

with youtube_dl.YoutubeDL(options) as ydl:
    ydl.download([url])
