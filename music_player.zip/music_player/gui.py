from tkinter import *
from PIL import ImageTk, Image
import pygame
import os

import model


window = Tk()
window.geometry('800x800')


menu_frame = Frame(window, bg='#333', width=200, height=600)
menu_frame.place(x = 0, y = 0)

music_list_frame = Frame(window, bg='#555', width=600, height=600)
music_list_frame.place(x=200, y=0)

bottom_frame = Frame(window, bg='#888', width=800, height=200)
bottom_frame.place(x=0, y=600)

cover_art_frame = Frame(bottom_frame, width=200, height=200, bg='#10ad33')
cover_art_frame.place(x=0, y=0)
image = ImageTk.PhotoImage(Image.open("images/cover_art/default.jpg"))
cover_lbl = Label(cover_art_frame, image=image)
cover_lbl.pack()

controller = Frame(bottom_frame, width=600, height=200)
controller.place(x=200, y=0, width=600, height=200)

# ************************************************************

playlist = model.playlist_1.get_songs()

current = 0
curr_pos = 0


# initialize pygame mixer
pygame.init()
pygame.mixer.init()

# widgets

# music lists
music_list = Listbox(music_list_frame, bg='#333', fg='#fff', width=60)
music_list.pack(pady=20)
if playlist:
    for i, song in enumerate(playlist):
        music_list.insert(i, song.song_title)

# define player control
play_img = PhotoImage(file='images/play.png')
pause_img = PhotoImage(file='images/pause.png')
stop_img = PhotoImage(file='images/stop.png')
next_img = PhotoImage(file='images/next.png')
prev_img = PhotoImage(file='images/prev.png')
# shuffle_img = PhotoImage(file='images\')
# repeat_img = PhotoImage(file='images\')

# functions


# music slider
slider_var = IntVar()
slider = Scale(controller, orient=HORIZONTAL,
               variable=slider_var, width=10, length=400, bg='#333',
               troughcolor='#fff', sliderlength=5, showvalue=0,
               cursor='hand1', bd=0)
slider.grid(row=0, column=0, columnspan=5, padx=20, pady=20)


volume_var = DoubleVar()


def set_volume(e):
    global volume_var
    pygame.mixer.music.set_volume(volume_var.get() / 100)
    if volume_var.get() <= 0:
        img = ImageTk.PhotoImage(Image.open("images/mute.png"))
        volume_lbl.configure(image=img)
        volume_img.image = img
    else:
        img = ImageTk.PhotoImage(Image.open("images/volume.png"))
        volume_lbl.configure(image=img)
        volume_img.image = img

volume_frame = Frame(controller, width=100)
volume_frame.grid(row=2, column=5)
volume_img = ImageTk.PhotoImage(Image.open("images/volume.png"))
volume_lbl = Label(volume_frame, image=volume_img)
volume_lbl.grid(row=0, column=0)
volume_slider = Scale(volume_frame, orient=HORIZONTAL,
                      variable=volume_var, width=10, length=70,
                      bg='#333', troughcolor='#fff', sliderlength=10,
                      cursor='hand1', bd=0, showvalue=0,
                      command=set_volume)

volume_var.set(pygame.mixer.music.get_volume() * 100)
volume_slider.grid(row=0, column=1, padx=20)


def load_song(cur):
    global song
    global slider
    
    base = os.getcwd() + '\music'

    song = os.path.join(base, playlist[cur].get_song_file())

    song_len = playlist[cur].get_song_duration()
    pygame.mixer.music.load(song)

    seconds = int(song_len % 60)
    minutes = int((song_len/60) % 60)

    slider['to'] = song_len
    print(f'{minutes}:{seconds}')
    if cur < len(playlist) - 1:
        next_song = os.path.join(base, playlist[cur + 1].get_song_file())
        pygame.mixer.music.queue(next_song)

load_song(current)


def time_counter():
    global timer_id
    if pygame.mixer.music.get_busy():
        # slider_var.set(pygame.mixer.music.get_pos() / 1000)
        slider_var.set(slider_var.get() + 1)
    else:
        slider_var.set(0)
    timer_id = window.after(1000, time_counter)

    

def play():
    if pygame.mixer.music.get_pos() > 0:
        pygame.mixer.music.unpause()

    else:
        pygame.mixer.music.play()
    time_counter()

    global value
    value = 0


def pause():
    global curr_pos
    pygame.mixer.music.pause()
    curr_pos = pygame.mixer.music.get_pos()


def stop():
    pygame.mixer.music.stop()


def next():
    pygame.mixer.music.stop()
    global current
    prev_song = current
    current += 1
    load_song(current)
    play()
    global value
    value = 0
    music_list.activate(current)


def prev():
    pygame.mixer.music.stop()
    global current
    prev_song = current
    current -= 1
    load_song(current)
    play()
    global value
    value = 0
    music_list.activate(current)


def skip_song(e):
    pause()
    window.after_cancel(timer_id)
    value = slider_var.get()
    pygame.mixer.music.set_pos(value)
    play()


slider['command'] = skip_song
# slider.bind('<ButtonRelease-1>', skip_song)
#  control btns
play_btn = Button(controller, image=play_img, borderwidth=0, command=play)
pause_btn = Button(controller, image=pause_img,
                   borderwidth=0, command=pause)
stop_btn = Button(controller, image=stop_img, borderwidth=0, command=stop)
next_btn = Button(controller, image=next_img, borderwidth=0, command=next)
prev_btn = Button(controller, image=prev_img, borderwidth=0, command=prev)


prev_btn.grid(row=1, column=0, padx=10, pady=30)
play_btn.grid(row=1, column=1, padx=10, pady=30)
pause_btn.grid(row=1, column=2, padx=10, pady=30)
stop_btn.grid(row=1, column=3, padx=10, pady=30)
next_btn.grid(row=1, column=4, padx=10, pady=30)


def play_selected(e):
    stop()
    selected_song = music_list.curselection()[0]
    load_song(selected_song)
    play()


music_list.bind('<Double-1>', play_selected)

# ****************************************************************

window.mainloop()