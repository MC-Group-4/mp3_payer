from mutagen.mp3 import MP3
import os

base = os.getcwd()

print(base + '\music')
class Song():
    def __init__(self, song_title, song_file, artist_name, album_title=None):
        self.song_title = song_title
        self.song_file = song_file
        self.album_title = album_title
        self.artist_name = artist_name
        self.set_song_duration()

    def __repr__(self):
        return f'<Song: {self.song_title}>'

    def get_song_title(self):
        return self.song_title

    def get_song_file(self):
        return self.song_file

    def get_song_title(self):
        return self.song_title
    
    def get_song_duration(self):
        return self.song_duration

    def set_song_duration(self):
        music_dir = base + '\music'
        song_file = os.path.join(music_dir, self.get_song_file())
        self.song_duration = MP3(song_file).info.length

class Artist():
    def __init__(self, artist_name, cover_art):
        self.artist_name = artist_name
        self.cover = cover
    
    def __repr__(self):
        return f'<Artist: {self.artist_name}>'

    def get_artist_name(self):
        return self.artist_name

    def get_cover_art(self):
        return self.cover_art

class Album():
    def __init__(self, album_title):
        self.album_title = album_title
        self.songs = []

    def __repr__(self):
        return f'<Album: {self.album_title}>'

    def add_song(self, song):
        self.songs.append(song)

    def get_songs(self):
        return self.songs

class Playlist():
    def __init__(self, playlist_name):
        self.playlist_name = playlist_name
        self.playlists = []

    def __repr__(self):
        return f'<Playlist: {self.playlist_name}>'

    def add_song(self, song_file):
        self.playlists.append(song_file)



    def get_songs(self):
        return self.playlists
        


party = Song(song_title = 'Party', song_file = 'Party.mp3', artist_name='Chris Brown')
no_role_models = Song(song_title = 'No Role Models', song_file = 'No Role Models.mp3', artist_name='JCole')
work_hard_play_hard = Song(song_title = 'Work Hard Play Hard', song_file = 'Work Hard Play Hard.mp3', artist_name='wiz khlifa')
pound_cake = Song(song_title = 'Pound cake', song_file = 'Pound cake.mp3', artist_name='Drake')
after_hour = Song(song_title = 'After Hour', song_file = 'After Hour.mp3', artist_name='The Weeknd')
middle_child = Song(song_title = 'Middle Child', song_file = 'Middle Child.mp3', artist_name='JCole')
peaches = Song(song_title = 'Peaches', song_file = 'Peaches.mp3', artist_name='Justin Bieber')
these_walls = Song(song_title = 'These Walls', song_file = 'These Walls.mp3', artist_name='Kendric Lamar')
leave_the_door_open = Song(song_title = 'Leave The Door Open', song_file = 'Leave The Door Open.mp3', artist_name='Burno Mars')

playlist_1 = Playlist(playlist_name='playlist_1')

playlist_1.add_song(party)
playlist_1.add_song(no_role_models)
playlist_1.add_song(work_hard_play_hard)
playlist_1.add_song(after_hour)
playlist_1.add_song(peaches)
# playlist_1.add_song(pound_cake)
# playlist_1.add_song(middle_child)
# playlist_1.add_song(these_walls)
# playlist_1.add_song(leave_the_door_open)




if __name__ == '__main__':
        print(playlist_1.get_songs())